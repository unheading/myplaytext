import 'package:app/routes/index.dart';
import 'package:flutter/cupertino.dart';

void main(List<String> args) {
  runApp(getRootWiget());
}